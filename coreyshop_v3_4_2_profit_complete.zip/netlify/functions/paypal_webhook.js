// PayPal webhook: verify signature via v2 API before sending downloads
const https=require('https');const sgMail=require('@sendgrid/mail');const {sign}=require('./_shared/token');sgMail.setApiKey(process.env.SENDGRID_API_KEY);

function reqToken(){return new Promise((resolve,reject)=>{
  const creds=Buffer.from(process.env.PAYPAL_CLIENT_ID+':'+process.env.PAYPAL_CLIENT_SECRET).toString('base64');
  const opts={method:'POST',hostname:(process.env.PAYPAL_ENV==='live'?'api.paypal.com':'api.sandbox.paypal.com'),path:'/v1/oauth2/token',headers:{'Authorization':'Basic '+creds,'Content-Type':'application/x-www-form-urlencoded'}};
  const req=https.request(opts,res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{try{resolve(JSON.parse(d).access_token)}catch(e){reject(e)}})});req.on('error',reject);req.write('grant_type=client_credentials');req.end();
});}

function verifySig(accessToken, headers, body){
  return new Promise((resolve,reject)=>{
    const payload=JSON.stringify({auth_algo:headers['paypal-auth-algo'],cert_url:headers['paypal-cert-url'],transmission_id:headers['paypal-transmission-id'],transmission_sig:headers['paypal-transmission-sig'],transmission_time:headers['paypal-transmission-time'], webhook_id:process.env.PAYPAL_WEBHOOK_ID, webhook_event:body});
    const opts={method:'POST',hostname:(process.env.PAYPAL_ENV==='live'?'api.paypal.com':'api.sandbox.paypal.com'),path:'/v1/notifications/verify-webhook-signature',headers:{'Authorization':'Bearer '+accessToken,'Content-Type':'application/json','Content-Length':Buffer.byteLength(payload)}};
    const req=https.request(opts,res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{try{resolve(JSON.parse(d))}catch(e){reject(e)}})});req.on('error',reject);req.write(payload);req.end();
  });
}

exports.handler=async(e)=>{
  try{
    const raw=e.isBase64Encoded?Buffer.from(e.body,'base64').toString('utf8'):e.body;
    const body=JSON.parse(raw||"{}");
    const token=await reqToken();
    const v=await verifySig(token, e.headers, body);
    if(!v || v.verification_status!=='SUCCESS'){ return {statusCode:400, body:'Invalid signature'}; }

    const eventType=body.event_type||'';
    if(eventType==='PAYMENT.CAPTURE.COMPLETED'||eventType==='CHECKOUT.ORDER.APPROVED'){
      const resource=body.resource||{};
      const email=(resource.payer&&resource.payer.email_address)||resource.email||body.email||'';
      const productId=(resource.custom_id||resource.invoice_id||'paypal-unknown');
      const t=sign({productId,exp:Date.now()+24*60*60*1000});
      const link=`${process.env.SITE_URL||''}/.netlify/functions/get_download?token=${encodeURIComponent(t)}`;
      if(email){ await sgMail.send({to:email,from:process.env.FROM_EMAIL,subject:`Your CoreyShop Download — ${productId}`,text:`Thanks for your purchase!\nDownload link (valid 24h): ${link}`}); }
    }
    return {statusCode:200, body:'ok'};
  }catch(err){ return {statusCode:500, body:err.toString()}; }
};