const crypto=require('crypto');const secret=process.env.DOWNLOAD_TOKEN_SECRET||'dev-secret';
function sign(p){const d=Buffer.from(JSON.stringify(p)).toString('base64url');const s=crypto.createHmac('sha256',secret).update(d).digest('base64url');return d+'.'+s;}
function verify(t){const [d,s]=t.split('.');if(!d||!s)throw Error('Bad token');const c=crypto.createHmac('sha256',secret).update(d).digest('base64url');if(c!==s)throw Error('Bad sig');const p=JSON.parse(Buffer.from(d,'base64url').toString());if(p.exp&&Date.now()>p.exp)throw Error('Expired');return p;}
module.exports={sign,verify};