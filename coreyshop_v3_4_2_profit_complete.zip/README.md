# CoreyShop v3.4.2 — Profit+ Complete

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/YOUR_USER/coreyshop-v3-4-2)

## What’s inside
- Hybrid storefront: Affiliate Trending + Owned digital products
- Upsell bundle to increase AOV
- Stripe + PayPal with **secure, time-limited** downloads
- **PayPal webhook signature verification** (production-ready)
- Weekly promos with Top 3 trending injected
- Weekly admin revenue report
- Admin dashboard (date filters + CSV export)
- **affiliate.json pre-filled with 100 offers** (updates monthly)

## Env Vars (Netlify → Site Settings → Environment variables)
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
SENDGRID_API_KEY=...
FROM_EMAIL=noreply@coreyshop.com
SITE_URL=https://your-site.netlify.app
DOWNLOAD_TOKEN_SECRET=choose_a_long_random_string
PAYPAL_ENV=live
PAYPAL_CLIENT_ID=...
PAYPAL_CLIENT_SECRET=...
PAYPAL_WEBHOOK_ID=...
ADMIN_EMAIL=coreyblackman76@gmail.com
ADMIN_KEY=choose_a_strong_key
CLICKBANK_AFFILIATE_ID=your_clickbank_id
CLICKBANK_MARKETPLACE_URL=https://YOUR_JSON_SOURCE   # optional

## Webhooks
Stripe:   /.netlify/functions/stripe_webhook   (checkout.session.completed)
PayPal:   /.netlify/functions/paypal_webhook   (PAYMENT.CAPTURE.COMPLETED)

## Scheduled Functions
send_weekly_email.js → weekly
send_admin_report.js  → weekly
update_trending.js    → monthly

## Deploy
1) Upload this folder to a GitHub repo (rename to coreyshop-v3-4-2 if you like)  
2) Click the **Deploy to Netlify** button above  
3) Enter env vars → Deploy  
4) Replace sample files in `netlify/functions/_assets/` with your real products
