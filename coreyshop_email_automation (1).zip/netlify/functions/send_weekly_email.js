
// netlify/functions/send_weekly_email.js
const sgMail = require('@sendgrid/mail');
const fs = require('fs');
const path = require('path');

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

exports.handler = async function(event, context) {
  try {
    const emails = JSON.parse(fs.readFileSync(path.join(__dirname, '../../emails.json')));
    const subscribers = fs.readFileSync(path.join(__dirname, '../../subscribers.csv'), 'utf8')
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('email'));

    if (subscribers.length === 0) {
      return { statusCode: 400, body: 'No subscribers found.' };
    }

    const weekNumber = Math.floor(Date.now() / (1000*60*60*24*7));
    const email = emails[weekNumber % emails.length];

    for (const to of subscribers) {
      const msg = {
        to,
        from: process.env.FROM_EMAIL,
        subject: email.subject,
        text: email.body.replace(/\[First Name\]/g, ''),
      };
      await sgMail.send(msg);
    }

    return { statusCode: 200, body: 'Emails sent successfully!' };
  } catch (err) {
    return { statusCode: 500, body: err.toString() };
  }
}
